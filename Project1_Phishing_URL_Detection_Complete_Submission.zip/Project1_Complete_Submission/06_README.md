# Project 1 - Phishing URL Detection System

## Student
Raju G H | BTech in Cyber Security, 6th Semester | GM University, Davangere

## Objective
Analyze a URL and classify it as Legitimate or Phishing using engineered URL features and a Random Forest classifier.

## Features
URL length, dot count, HTTPS usage, IP-address usage, @ count, hyphen count, suspicious keyword count, subdomain count, path depth, digit count, and query parameter count.

## Run in VS Code terminal
From the project `src` folder:

    python -m pip install -r ../requirements.txt
    python train_model.py
    python app.py

Open http://127.0.0.1:5000

## Testing
Use the synthetic URLs listed in `reports/test_results.txt`. Do not visit or test real malicious infrastructure.

## Notes
The included 24-row dataset is a small educational/synthetic dataset used for implementation validation. The 100% demo score must not be interpreted as real-world performance. A larger legally obtained dataset should be used for final research evaluation.
